from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from modules.dwd import lade_warnungen, statistik, landkreis_warnungen

app = FastAPI(title="Wetterstudio Bad Feilnbach AI")

# Statische Dateien
app.mount("/static", StaticFiles(directory="static"), name="static")

# HTML-Templates
templates = Jinja2Templates(directory="templates")


@app.get("/api/warnungen")
async def api_warnungen():

    daten = lade_warnungen()
    return landkreis_warnungen(daten)


@app.get("/")
async def startseite(request: Request):

    daten = lade_warnungen()

    stats = statistik(daten)
    landkreise = landkreis_warnungen(daten)

   

    
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "titel": "Wetterstudio Bad Feilnbach AI",
"landkreise": landkreise,
            "warnungen": stats["gesamt"],

            "gewitter": stats["gewitter"],

            "tornados": stats["tornado"],

            "temperatur": "-- °C",

            "wind": "-- km/h",

            "regen": "-- mm",

            "gelb": stats["gelb"],
            "orange": stats["orange"],
            "rot": stats["rot"],
            "violett": stats["violett"],

            "sturm": stats["sturm"],
            "starkregen": stats["starkregen"],
            "hitze": stats["hitze"],
            "schnee": stats["schnee"],
            "titel_seite": "Wetterstudio Bad Feilnbach AI",
        },
    )